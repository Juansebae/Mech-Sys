#!/bin/bash

AA="1 3 3"
for a in $AA; do
    echo $a
done
